import React from 'react'
import CheckReservationInfo from '../../components/Ours/Our/CheckReservationInfo'

// CheckReservtion에서 CheckReservtionInfo로 연결해주는 api

const add = () => {
  return (
    <CheckReservationInfo />
  )
}

export default add