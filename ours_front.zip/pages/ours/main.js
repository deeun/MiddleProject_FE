import React from 'react'
import Main from '../../components/Main/Main'

// ReservationFinish에서 Main으로 연결해주는 api

const add = () => {
  return (
    <Main />
  )
}

export default add