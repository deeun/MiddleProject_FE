import React from 'react'
import Reservation from '../../components/Ours/Our/Reservation'

// Details에서 Reservation로 연결해주는 api

const add = () => {
  return (
    <Reservation />
  )
}

export default add