import React from 'react'
import ReservationFinish from '../../components/Ours/Our/ReservationFinish'

// Reservation에서 ReservationFinish로 연결해주는 api

const add = () => {
  return (
    <ReservationFinish />
  )
}

export default add