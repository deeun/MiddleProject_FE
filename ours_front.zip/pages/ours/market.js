import React from 'react'
import Market from '../../components/Ours/Our/Market'

// 네비게이션바에서 CheckReservtion로 연결해주는 api

const add = () => {
  return (
    <Market />
  )
}

export default add