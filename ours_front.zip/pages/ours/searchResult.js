import React from 'react'
import SearchResult from '../../components/Ours/Our/SearchResult'


const add = () => {
  return (
    <SearchResult />
  )
}

export default add
