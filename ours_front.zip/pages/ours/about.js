import React from 'react'
import About from '../../components/Ours/Our/About'

// 네비게이션바에서 CheckReservtion로 연결해주는 api

const add = (props) => {
  // console.log(props);
  return (
    <About />
    )
  }

export default add