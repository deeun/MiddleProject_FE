import React from 'react'
import Login from '../../components/Ours/Our/Login'

// Main에서 ExperienceList로 연결해주는 api

const add = () => {
  return (
    <Login />
  )
}

export default add