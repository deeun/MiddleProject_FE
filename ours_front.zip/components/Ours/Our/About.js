import React from 'react'
import Our from './Our'

const About = (props) => {
  console.log(props);
  return (
    <>
      <h1>농어촌 체험이란</h1>
      <br/>
    </>
  )
}

export default About;

