import React from 'react'
import { useRouter } from 'next/router'

// 농수산물 구매하기

const SearchResult = (props) => {
    const router = useRouter();

  return (
    <>
    <button>홈으로</button>
    </>
  )
}

export default SearchResult